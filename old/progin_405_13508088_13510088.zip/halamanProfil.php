<!DOCTYPE html>
<html lang="en">
	<body>
		
		<?php include "header.php"?>
		<div class="body">
		
			<div class="profile">
				<img src="images/User1.jpg" class="profpic">
				<p class="nama">Only for you.</p>
				<input type="submit" id="editprofilebutton" value="Edit Profile" onclick="editProfile()">
				firauliya@yahoo.com // @firauliya
				<div class="atributprofile">Nama Lengkap</div>
					<div id="atributfullname">Syafira Fitri Auliya </div>
				<br>
				
				<div class="atributprofile">Birthday</div>
                <div id="atributbirthday">15 Maret 2013</div>
				
				<br>
				<br>
				<div class="atributprofile">Password</div>
                <div id="atributpassword">(tidak ditampilkan)</div>
				<br>
				<div class="atributprofile">Confirm Password</div>
                <div id="atributconfirmpassword">(tidak ditampilkan)</div>
			</div>	
						
						
			<div class="catagories">
				<br>
                <h3>Daftar Tugas</h3>
				<a href="rinciantugas5.html">Beli Nasi Timbel</a>
				<br />
				<a href="rinciantugas2.html">Beli Ayam Broiler</a>
            </div>
            <div class="contents">
				<br>
                <h3>Tugas Selesai</h3>
                <a href="rinciantugas5.html">Beli Nasi Timbel</a>
				<br />
				
			</div>
			
			
            
		</div>
		<footer>
            CanDo. Yes you can!
            <br>
            About us
		</footer>
	</body>

</html>

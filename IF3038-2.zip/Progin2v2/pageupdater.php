
<?php
	$ID_Tugas=$_GET['ID_Tugas'];
	$con=mysqli_connect("localhost","progin","progin","progin_405_13510099");
	$result=mysqli_query($con,"SELECT komentar FROM komentar_tugas WHERE ID_Tugas='".$ID_Tugas."';");
	$banyak_komentar=0;
	$banyak_halaman=0;
	
	while ($row=mysqli_fetch_row($result))
	{
		$banyak_komentar++; //ngitung banyak komentar
	}

	if ($banyak_komentar % 10 == 0) {$banyak_halaman=$banyak_komentar/10;}; //jika byk halaman kelipatan 10
	if ($banyak_komentar % 10 != 0) {$banyak_halaman=floor($banyak_komentar/10)+1;}; //jika bayak halaman bukan kelipatan 10
	$i=1;
	
	while ($i <= $banyak_halaman)
	{
		echo "<div onclick=\"page_view(".$i.")\">".$i."</div>";
		$i++;
	}	
	
	mysqli_close($con);
?>
<html>
	<head>
		<title>asdasd</title>
	</head>
	<body>
		<?php	
			if ($_FILES["files"]["error"] > 0)
				{
					echo "Error: ".$_FILES["files"]["error"]."<br>";
				}
			else
				{
					echo "Type: ".$_FILES["file"]["name"]."<br>";
					echo "Size: ".$_FILES["file"]["type"]."<br>";
					echo "Size: ".$_FILES["file"]["size"]."<br>";
					echo "Stored in: ".$_FILES["file"]["tmp_name"];
				}				
		?>
	</body>
</html>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Dashboard</title>
		<link rel="stylesheet" href="style.css" type="text/css" media="screen">
	</head>
	<body>
		<?php
			$con = mysql_connect("localhost","root");
			mysql_select_db("progin_405_13510099");
			$result=mysql_query("SELECT DISTINCT kategori FROM tugas;");
			$dis_cat=array();
			$i=0;
			while ($row=mysql_fetch_array($result))
			{
				$dis_cat[$i]=$row["kategori"];
				$i=$i+1;
			}
			
			$i=0;
			
			echo "Daftar kategori: ";
			
			
			while ($i < count($dis_cat))
			{
				echo $dis_cat[$i].",";
				$i=$i+1;
			}
			
			$result=mysql_query("SELECT * FROM tugas");
			
			$array_id_tugas=array();
			$array_nama_tugas=array();
			$array_deadline=array();
			$array_status_tugas=array();
			$array_tag=array();
			$array_kategori=array();
			
			$i=0;
			while ($row=mysql_fetch_array($result))
			{
				$array_id_tugas[$i]=$row["ID_tugas"];
				$array_nama_tugas[$i]=$row["nama_tugas"];
				$array_deadline[$i]=$row["deadline"];
				$array_status_tugas[$i]=$row["status"];
				$array_kategori[$i]=$row["kategori"];
				$array_tag[$i]=$row["tag"];
				$i++;
			}
			
			
			$i=0;
		
			echo "<div id=\"tasklist\">";
			while ($i < count ($array_nama_tugas))
			{
				echo "Nama task: ".$array_nama_tugas[$i]."<br>";
				echo "Tanggal deadline: ".$array_deadline[$i]."<br>";
				echo "Tag: ".$array_tag[$i]."<br>";
				echo "Status: ".$array_status_tugas[$i]."<br>";
				$i++;
			}	
			echo "</div>";
			$i=0;
			
			mysql_close($con);
		?>
	</body>
</html>
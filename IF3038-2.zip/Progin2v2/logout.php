<?php
//function start
session_start();
extract($_SESSION);
unset($_SESSION['userid']);
header( 'Location: index.php' );
?>

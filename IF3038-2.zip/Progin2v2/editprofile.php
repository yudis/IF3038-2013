
<?php
	//editprofile.php digunakan untuk profile.php dalam pengeditan profile user
	$username="username1";//username sementara
	$nama_lengkap=$_REQUEST["editfullname"];
	$password=$_REQUEST["editpassword"];
	$email=$_REQUEST["editemail"];
	$birthday=$_REQUEST["editbirthday"];
	$con=mysqli_connect("localhost","progin","progin","progin_405_13510099");
	mysqli_query($con,"UPDATE user SET nama_lengkap='".$nama_lengkap."' where username='".$username."';");
	mysqli_query($con,"UPDATE user SET password='".$password."' where username='".$username."';");
	mysqli_query($con,"UPDATE user SET email='".$email."' where username='".$username."';");
	mysqli_query($con,"UPDATE user SET tanggal_lahir='".$birthday."' where username='".$username."';");
	mysqli_query($con,"UPDATE user SET avatar='".$_FILES["file"]["name"]."' where username='".$username."';");
	
	$allowedExts = array("gif", "jpeg", "jpg", "png");
$extension = end(explode(".", $_FILES["file"]["name"]));
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 20000)
&& in_array($extension, $allowedExts))
  {
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    }
  else
    {
    echo "Upload: " . $_FILES["file"]["name"] . "<br>";
    echo "Type: " . $_FILES["file"]["type"] . "<br>";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
    echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br>";

    if (file_exists("avatar/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
	
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "avatar/" .$_FILES["file"]["name"]);
      echo "Stored in: " . "avatar/" .$_FILES["file"]["name"];
      }
    }
  }
else
  {
  echo "Invalid file";
  }
?>
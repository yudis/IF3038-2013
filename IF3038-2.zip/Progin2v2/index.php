<!--coba login-->
<head>
	<title>Shared</title>
	<link rel="stylesheet" type="text/css" media="all" href="style.css" />
	<script src="registrasi.js"></script>
</head>

<body>
	
<header >	
			
	<div id="tes">
	<h1 id="logo"><img src="images/logo.png"/></a>
	</div>
</header>
			
		<div id="logincontent">
			<p> LOGIN </p>
				<form name="login" action="login.php" id="formlogin" method="POST" onsubmit="return checkLogin();">
				<p>Username&emsp;&emsp;&emsp;&emsp; :&emsp;<input type="text" name="userid" required></p>
				<p>Password &emsp;&emsp;&emsp;&emsp; :&emsp;<input type="password" name="pwd" required></p>
				<input type="submit" value="Login"/>&emsp;
				<input type="reset" value="Cancel"/>
				</form>
			 <p>REGISTER</p>
				<form name="register" action="register.php" method="POST" id="formregister"  onsubmit="return checkValidation();">
				<p>Username&emsp;&emsp;&emsp;&emsp;:&emsp; <input name="username" size="30" type="text" maxlength="20" onkeyup="checkUsername();checkPassword();" required></p>
				<p>Password &emsp;&emsp;&emsp;&emsp;:&emsp; <input name="password" type="password" size="30" maxlength="20" onkeyup="checkPassword();"  required></p>
				<p>Confirm Password &nbsp: &emsp;<input name="confirm" type="password" size="30" maxlength="20" onkeyup="checkConfirmPassword();"  required> </p>
				<p>Full Name&emsp;&emsp;&emsp;&emsp;:&emsp;  <input name="nama_lengkap" type="text" size="30" maxlength="30" onkeyup="checkNama();" required></p>				
				<p>Email&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&emsp;  <input name="email" type="text" size="30" maxlength="50" onkeyup="checkEmail();checkPassword();" required ></p> 
				<p>Birth &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&emsp;<input name="tanggal_lahir" type="date" required ></p>
				<p>Upload Avatar &emsp;&emsp;:&emsp;<input name="avatar" type="file" size="30" accept="image/jpeg" onchange="check_extension();"  required></p>
				<input name="btnsubmit" type="submit" value="Register Me!" >
				</form>
			<?php /*
		if (isset($_POST['submit'])) {
			$username 		=$_POST['username'];
			$password 		=$_POST['password'];
			$confirm  		=$_POST['confirm'];
			$email	  		=$_POST['email'];
			$nama_lengkap 	=$_POST['nama_lengkap'];
			$tanggal_lahir	=$_POST['tanggal_lahir'];
			$avatar			=$_POST['avatar'];
			
			$conn = mysqli_connect("localhost", "progin", "progin");

			if (mysqli_connect_errno()) {
			echo "Koneksi ke server gagal dilakukan";
			exit();
			}

			$sql= "INSERT INTO user(username,password,nama_lengkap,email,tanggal_lahir, avatar) VALUES ('$username','$password','$nama_lengkap','$email','$avatar')";

			mysqli_query($conn, $sql);
			$num = mysqli_affected_rows($conn);
			
			
			if ($num > 0) {
			header("Location: dashboard.php");}
			else {
			header("Location: failreg.php");;}
			
			mysql_close($conn);
		 }*/
		 ?>
		</div>
		<footer id="colophon">
			<div id="site-generator">
				<p>&copy; <a href="#">KITA</a>-IF3038 Pemrograman Internet 2013 <br />
				</p>
			</div>
		</footer>
		
</body>
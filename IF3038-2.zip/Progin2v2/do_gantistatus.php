<?php
	$id=$_GET['ID_tugas'];
	$status=$_GET['status'];
	
	$con = mysql_connect("localhost","root");
	mysql_select_db("progin_405_13510099");
	
	if($status=='Finish') {
		$query=("
		UPDATE 
		tugas 
		SET  status =  'Unfinish' 
		WHERE  ID_tugas =  '$id' ");
	} else {
		$query=("
		UPDATE 
		tugas 
		SET  status =  'Finish' 
		WHERE  ID_tugas =  '$id' ");
		}
	
			$hasil= mysql_query($query);
			if($hasil) {
				echo "<br/>" . "Data telah tersimpan.";
			}else echo "<br/>"."Error! Data tidak terupdate";

?>
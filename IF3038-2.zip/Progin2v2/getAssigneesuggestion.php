<?php
// Fill up array with names
	$con = mysql_connect("localhost","progin","progin");
		if (!$con)
		{
			die('Could not connect: ' . mysql_error());
		}
	mysql_select_db("progin_405_13510099", $con);
	$results = mysql_query("SELECT * FROM user");
	
	while($result = mysql_fetch_array($results)) {
		$a[]=$result['username'];
	}
	mysql_close($con);

//get the q parameter from URL
$q=$_GET["q"];

//lookup all hints from array if length of q>0
if (strlen($q) > 0)
  {
  $hint="";
  for($i=0; $i<count($a); $i++)
    {
    if (strtolower($q)==strtolower(substr($a[$i],0,strlen($q))))
      {
      if ($hint=="")
        {
        $hint=$a[$i];
        }
      else
        {
        $hint=$hint.";".$a[$i];
        }
      }
    }
  }

// Set output to "no suggestion" if no hint were found
// or to the correct values
if ($hint == "")
  {
  $response=$q;
  }
else
  {
  $response=$hint;
  }

//output the response
echo $response;
?>
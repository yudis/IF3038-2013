<?php
$username 		=$_POST['username'];
			$password 		=$_POST['password'];
			$confirm  		=$_POST['confirm'];
			$email	  		=$_POST['email'];
			$nama_lengkap 	=$_POST['nama_lengkap'];
			$tanggal_lahir	=$_POST['tanggal_lahir'];
			$avatar			=$_POST['avatar'];
			$fn 	=$_FILES["fileattach"]["name"];
			$conn = mysql_connect("localhost","progin","progin");
			mysql_select_db("progin_405_13510099");

			$sql= "
			INSERT INTO  `progin_405_13510099`.`user` (
			`username` ,
			`password` ,
			`email` ,
			`nama_lengkap` ,
			`tanggal_lahir` ,
			`avatar`
			)
			VALUES (
			'$username',  '$password',  '$email',  '$nama_lengkap',  '$tanggal_lahir',  '$fn'
			);
			";
			$hasil= mysql_query($sql);
			if($hasil) {
	if ($_FILES["file"]["error"] > 0)
		{
		$_FILES["file"]["error"] . "<br />";
		}
	  else
		{
	
		  move_uploaded_file($_FILES["file"]["tmp_name"],
		  "avatar/" . $_FILES["file"]["name"]);
			
			
			header("Location: mainpage.php");
		}
			
			mysql_close($conn);
			}
			?>
<?php
	//UDAH JALANNNNNNNNNNNNNN
	//$ID_Tugas="Tugas1";
	//$username="username1";
	//$komentar="blabla";
	
	$ID_Tugas=$_GET['ID_Tugas'];
	$username=$_GET['username'];
	$komentar=$_GET['komentar'];
	$date=date('Y-m-d H:i:s'); //ngambil daate
	$con=mysqli_connect("localhost","progin","progin","progin_405_13510099");
	$sql1="INSERT INTO komentar_tugas VALUES ('";
	$sql2=$ID_Tugas."','";
	$sql3=$username."','";
	$sql4=$komentar."','";
	$sql5=$date."');";
	$sql=$sql1.$sql2.$sql3.$sql4.$sql5;
	$query=mysqli_query($con,$sql);
	mysqli_close($con);
?>
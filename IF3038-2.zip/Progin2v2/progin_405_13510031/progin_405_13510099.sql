-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2013 at 04:42 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `progin_405_13510099`
--

-- --------------------------------------------------------

--
-- Table structure for table `asignee_tugas`
--

CREATE TABLE IF NOT EXISTS `asignee_tugas` (
  `ID_tugas` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `asignee_tugas`
--

INSERT INTO `asignee_tugas` (`ID_tugas`, `username`) VALUES
('Tugas2', 'username1'),
('Tugas2', 'username3'),
('Tugas3', 'username1'),
('Tugas3', 'username2'),
('Tugas1', 'username2'),
('Tugas1', 'username2'),
('Tugas1', 'username2'),
('', 'username3'),
('Tugas1', 'username3'),
('Tugas1', 'huhu'),
('Tugas1', 'lol');

-- --------------------------------------------------------

--
-- Table structure for table `attachment_tugas`
--

CREATE TABLE IF NOT EXISTS `attachment_tugas` (
  `ID_tugas` varchar(50) NOT NULL,
  `nama_attachment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Berisi nama file dari attachment setiap tugas';

-- --------------------------------------------------------

--
-- Table structure for table `komentar_tugas`
--

CREATE TABLE IF NOT EXISTS `komentar_tugas` (
  `ID_Tugas` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `komentar` text NOT NULL,
  `waktu_komentar` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Berisi komentar dari user pada tugas';

--
-- Dumping data for table `komentar_tugas`
--

INSERT INTO `komentar_tugas` (`ID_Tugas`, `username`, `komentar`, `waktu_komentar`) VALUES
('Tugas1', 'username1', 'whos your daddy?', '2013-03-27 10:14:29'),
('Tugas1', 'username2', 'whoawhoa', '2013-03-12 18:30:27'),
('Tugas3', 'username3', 'wowowoow', '2013-03-18 07:11:10'),
('Tugas1', 'username1', 'lalalalalala', '2013-03-22 18:14:59');

-- --------------------------------------------------------

--
-- Table structure for table `tag_tugas`
--

CREATE TABLE IF NOT EXISTS `tag_tugas` (
  `ID_Tugas` varchar(50) NOT NULL,
  `Tag` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Berisi tag tugas';

--
-- Dumping data for table `tag_tugas`
--

INSERT INTO `tag_tugas` (`ID_Tugas`, `Tag`) VALUES
('Tugas2', 'php'),
('Tugas2', 'jsp'),
('Tugas3', 'blablah'),
('Tugas1', 'addedtag'),
('Tugas1', 'addedtag'),
('Tugas1', 'addedtag'),
('Tugas1', 'addedtag'),
('Tugas1', 'lalallalalalal'),
('Tugas1', 'triliil'),
('Tugas1', '22d');

-- --------------------------------------------------------

--
-- Table structure for table `tugas`
--

CREATE TABLE IF NOT EXISTS `tugas` (
  `ID_tugas` varchar(50) NOT NULL,
  `nama_tugas` varchar(50) NOT NULL,
  `deadline` date NOT NULL,
  `attachment` varchar(50) NOT NULL,
  `tag` varchar(50) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `pembuat_tugas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Berisi data tentang tugas';

--
-- Dumping data for table `tugas`
--

INSERT INTO `tugas` (`ID_tugas`, `nama_tugas`, `deadline`, `attachment`, `tag`, `kategori`, `status`, `pembuat_tugas`) VALUES
('Tugas1', 'nama_tugas1', '2000-10-10', '', '', 'kategori1', 'Selesai', 'username1'),
('Tugas2', 'nama_tugas2', '2012-03-13', '', '', 'kategori2', 'Belum', 'username2'),
('Tugas3', 'nama_tugas3', '2012-03-13', '', '', 'kategori3', 'Selesai', 'username3');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `avatar` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Berisi tentang data user ';

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `email`, `nama_lengkap`, `tanggal_lahir`, `avatar`) VALUES
('mgemaakbar', 'password', 'email@domain.com', 'Akbar', '2013-03-13', ''),
('username1', '123456789', 'l@l.com', 'nanana na', '1780-01-01', 'buatheader.gif'),
('username2', 'password2', 'email2@site.com', 'nama2', '2013-03-18', ''),
('username3', 'password3', 'email3@site.com', 'nama3', '2013-03-26', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

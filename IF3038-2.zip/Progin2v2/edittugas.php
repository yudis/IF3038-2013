<?php
	//ingat tabel assigne yang ada di database tidak bernama 'assignee_tugas' tapi 'asignee_tugas'

	$ID_Tugas=$_GET['ID_Tugas'];
	$tambah_assignee=$_GET['tambah_assignee'];
	$hapus_assignee=$_GET['hapus_assignee'];
	$tambah_tag=$_GET['tambah_tag'];
	$hapus_tag=$_GET['hapus_tag'];
	$deadline=$_GET['deadline'];

	//belum dimasukin kasus dimana textfield dikosongkan
	$con=mysqli_connect("localhost","progin","progin","progin_405_13510099");
	
	if ($tambah_assignee != "")
	{$updateassignee=mysqli_query($con,"INSERT INTO asignee_tugas VALUES ('".$ID_Tugas."','".$tambah_assignee."');");};

	if ($tambah_tag != "") {$updatetag=mysqli_query($con,"INSERT INTO tag_tugas VALUES ('".$ID_Tugas."','".$tambah_tag."');");};

	if ($hapus_tag != "") {$queryhapustag=mysqli_query($con,"DELETE FROM tag_tugas WHERE ID_tugas='".$ID_Tugas."' AND tag='".$hapus_tag."';");};

	if ($hapus_assignee != "") {$queryhapusassignee=mysqli_query($con,"DELETE FROM asignee_tugas WHERE ID_tugas='".$ID_Tugas."' AND username='".$hapus_assignee."';");};
	
	if ($deadline != "") {$updatedeadline=mysqli_query($con,"UPDATE tugas SET deadline='".$deadline."' WHERE ID_tugas='".$ID_Tugas."';");};
	
	$array_namalengkap_assignee=array();
	$array_tag_tugas=array();
	$array_username_assignee=array();
	$i=0;
	
	
	$result=mysqli_query($con,"SELECT * FROM asignee_tugas WHERE ID_tugas='".$ID_Tugas."';");
	
	//mengambil data assignee tugas dari database, memasukkannya ke dalam array
	while ($row=mysqli_fetch_array($result))
	{
		$array_username_assignee[$i]=$row['username'];
		$i++;
	}
	
	$i=0;
	//mengambil nama lengkap assignee, memanfaatkan username2nya yang sudha diambil tadi
	
	while ($i < count($array_username_assignee))
	{
		$result=mysqli_query($con,"SELECT * FROM user WHERE username='".$array_username_assignee[$i]."';");
		$row=mysqli_fetch_array($result);
		$array_namalengkap_assignee[$i]=$row['nama_lengkap'];
		$i++;	
	}
	$i=0;
	//mengambil data tags

	$result=mysqli_query($con,"SELECT * FROM tag_tugas WHERE ID_tugas='".$ID_Tugas."';");
	
	while ($row=mysqli_fetch_array($result))
	{
		$array_tag_tugas[$i]=$row['Tag'];
		$i++;
	}
	
	$i=0;
	echo "<br>";
	echo "<div id=\"atribut\">";
	echo "Assignee(s): ";
	while ($i<count($array_namalengkap_assignee))
	{
	echo "<a href=\"profile.php?namalengkap=";
	echo $array_namalengkap_assignee[$i];
	echo "\">";
	echo $array_namalengkap_assignee[$i];
	echo "</a> ,";
	$i++;
	}

	$i=0;
	echo "<br>";
	echo "Tag tugas: ";
	while ($i<count($array_tag_tugas))
	{
		echo $array_tag_tugas[$i].", ";
		$i++;
	}
	echo "<br>";
	echo "Deadline : ".$deadline;
	
	echo "</div>"; //penutup tag div atribut
	
	mysqli_close($con);
?>
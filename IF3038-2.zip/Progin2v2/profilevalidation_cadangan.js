
function checkUsername() {
	var uname=document.forms["editprofile"][""].value;
    if(uname == "" || uname==null)
        {document.getElementById("usernamewarning").innerHTML="*Username tidak boleh kosong";return false;}
    else
    if(uname.length<5)
        {document.getElementById("usernamewarning").innerHTML="*Username minimal 5 huruf";return false;}
    else
        {document.getElementById("usernamewarning").innerHTML="";return true;}
}

function checkPassword() {
var pass=document.forms["editprofile"]["editpassword"].value;
var email=document.forms["editprofile"]["editemail"].value;
    if(pass.value == "" || pass.value == null)
        {document.getElementById("passwordwarning").innerHTML="*Password tidak boleh kosong";return false;}
    else
    if(pass.value.length<8)
        {document.getElementById("passwordwarning").innerHTML="*Password minimal 8 karakter";return false;}
    else
    if(pass.value == email.value)
        {document.getElementById("passwordwarning").innerHTML="*Password tidak sama dengan e-mail";return false;}
    else
        {document.getElementById("passwordwarning").innerHTML="";return true;}
}

function checkConfirmPassword() {
var pass1=document.forms["editprofile"]["editpassword"].value;
var pass2=document.forms["editprofile"]["editconfirmpassword"].value;
    if(pass1.value != pass2.value)
        {document.getElementById("confirmwarning").innerHTML="*Password tidak cocok";return false;}
    else
        {document.getElementById("confirmwarning").innerHTML="";return true;}
}

function checkNama() {
var nama=document.forms["editprofile"]["editfullname"].value;
    var spacepos=nama.value.indexOf(" ");
    if(nama.value == "" || nama.value == null)
        {document.getElementById("namawarning").innerHTML="*Nama tidak boleh kosong";return false;}
    else
        if(spacepos<0)
            {document.getElementById("namawarning").innerHTML="*Nama minimal 2 kata";return false;}
        else
            {document.getElementById("namawarning").innerHTML="";return true;}
}

function checkEmail() {
	var email=document.forms["editprofile"]["editemail"].value;
    var atpos=email.value.indexOf("@");
    var dotpos=email.value.lastIndexOf(".");
    if(email.value == "" || email.value == null)
        {document.getElementById("emailwarning").innerHTML="*E-mail tidak boleh kosong";return false;}
    else
        if(atpos<1 || dotpos<atpos+1 || (dotpos+2)>=email.length)
            {document.getElementById("emailwarning").innerHTML=("*e-mail tidak valid");return false;}
        else
            {document.getElementById("emailwarning").innerHTML="";return true;}
}


function check_extension() {
		var filename=document.forms["editprofile"]["editavatar"].value;
      var re = /\..+$/;
      var ext = filename.match(re);
      if(!(ext==".jpg" || ext==".jpeg"))
           {document.getElementById("avatarwarning").innerHTML="ekstensi file tidak diterima";return false;}
       else
           {document.getElementById("avatarwarning").innerHTML="";return true;}
}


function checkValidation() {
    return (checkUsername() && checkPassword() && checkConfirmPassword() && checkNama() && checkEmail() && check_extension());
}


}
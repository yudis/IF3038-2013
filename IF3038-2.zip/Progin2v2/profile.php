<!DOCTYPE HTML>
<html>
	<head>
		<?php $username='username1' ?>
		<title>ToDoList - Profile page of <?php echo $name;?></title>
		<link rel="stylesheet" href="style.css" type="text/css" media="screen">
	</head>
	<body>
	<script>
function checkPassword() {
var pass=document.forms["editprofile"]["editpassword"];
var email=document.forms["editprofile"]["editemail"];
    if(pass.value == "" || pass.value == null)
        {document.getElementById("passwordwarning").innerHTML="*Password tidak boleh kosong";return false;}
    else
    if(pass.value.length<8)
        {document.getElementById("passwordwarning").innerHTML="*Password minimal 8 karakter";return false;}
    else
    if(pass.value == email.value)
        {document.getElementById("passwordwarning").innerHTML="*Password tidak sama dengan e-mail";return false;}
    else
        {document.getElementById("passwordwarning").innerHTML="";return true;}
}

function checkConfirmPassword() {
var pass1=document.forms["editprofile"]["editpassword"];
var pass2=document.forms["editprofile"]["editconfirmpassword"];
    if(pass1.value != pass2.value)
        {document.getElementById("confirmwarning").innerHTML="*Password tidak cocok";return false;}
    else
        {document.getElementById("confirmwarning").innerHTML="";return true;}
}

function checkNama() {
var nama=document.forms["editprofile"]["editfullname"];
    var spacepos=nama.value.indexOf(" ");
    if(nama.value == "" || nama.value == null)
        {document.getElementById("namawarning").innerHTML="*Nama tidak boleh kosong";return false;}
    else
        if(spacepos<0)
            {document.getElementById("namawarning").innerHTML="*Nama minimal 2 kata";return false;}
        else
            {document.getElementById("namawarning").innerHTML="";return true;}
}

function checkEmail() {
	var email=document.forms["editprofile"]["editemail"];
    var atpos=email.value.indexOf("@");
    var dotpos=email.value.lastIndexOf(".");
    if(email.value == "" || email.value == null)
        {document.getElementById("emailwarning").innerHTML="*E-mail tidak boleh kosong";return false;}
    else
        if(atpos<1 || dotpos<atpos+1 || (dotpos+2)>=email.length)
            {document.getElementById("emailwarning").innerHTML=("*e-mail tidak valid");return false;}
        else
            {document.getElementById("emailwarning").innerHTML="";return true;}
}


function check_extension() {
		var filename=document.forms["editprofile"]["editavatar"];
      var re = /\..+$/;
      var ext = filename.match(re);
      if(!(ext==".jpg" || ext==".jpeg"))
           {document.getElementById("avatarwarning").innerHTML="ekstensi file tidak diterima";return false;}
       else
           {document.getElementById("avatarwarning").innerHTML="";return true;}
}

function check_perubahan()
{
	var nama=document.getElementById("field_nama").value;
	var email=document.getElementById("field_email").value;
	var ultah=document.getElementById("field_tanggal").value;
	document.getElementById("namawarning").innerHTML="Field nama tidak berubah.";
	
}

function checkValidation() {
    return (checkPassword() && checkConfirmPassword() && checkNama() && checkEmail());
}



	</script>
		
		<?php
			$con=mysqli_connect("localhost","progin","progin","progin_405_13510099");
			if (mysqli_connect_errno($con)) {echo "Failed to connect to MySQL: ".mysqli_connect_error();}
		?>		
		<!-- menampilkan masing-masing atribut dari user -->
		<?php
			
			//name adalah variabel untuk nama lengkap
			$result=mysqli_query($con,"SELECT * FROM user WHERE user.username='".$username."'");
			$row=mysqli_fetch_array($result);
			
			//menampilkan beberapa atribut user
			echo "Username: ".$row["username"]."</br>";
			echo "Nama lengkap: "."<div id=\"field_nama\">".$row["nama_lengkap"]."</div>"."</br>";
			echo "Tanggal lahir: "."<div id=\"field_tanggal\">".$row["tanggal_lahir"]."</div>"."</br>"; 
			echo "Email: ".$row["email"]."</br>";
			echo "Avatar: ";
			echo "<img src=\""."avatar/".$row["avatar"]."\"></img><br>";
			
			//melakukan query SQL yang mengambil tugas-tugas yang terkait dengan username
			$result=mysqli_query($con,"SELECT * FROM asignee_tugas WHERE username='".$username."'");
			
			$array_tugas=array();
			
			$i=0;
			
			//memasukkannnya kedalam array 
			while ($row=mysqli_fetch_array($result))
			{
				$array_tugas[$i]=$row['ID_tugas'];
				$i++;
			}
			
			$i=0;
			
		//ngetes arraynya jalan apa tidak, dengan mengeluarkamn valuenya
			
			$array_status_tugas=array(); //array berisi status tugas, apakah sudah dikerjakan atau belum
			
			//memasukkan status tugas ke dalam array yang telah dibuat sebelum ini
			while ($i < count($array_tugas)) //kondisi berhenti adalah ketika semua status tugas telah dimasukkan, yaitu sebanyak tugas yang dimiliki
			{
				$result=mysqli_query($con,"SELECT status FROM tugas WHERE ID_tugas='".$array_tugas[$i]."'");
				$row=mysqli_fetch_array($result);
				$array_status_tugas[$i]=$row['status'];
				$i++;
			}
		
			echo "Task yang sudah dikerjakan: <br>";
			
			$i=0;
			
			//ini buat bikin hyperlink ke tugas yang dimiliki user
			/*echo "<a href=\"detailtugas.php?ID_tugas=".$array_tugas[$i].">".$nama_tugas[$i]."</a>";*/
			
			//mengambil nama2 tugas, menggunakan ID_tugas yang sudah diperoleh, melakukan query sql
			while ($i < count($array_tugas))
			{
				$result=mysqli_query($con,"SELECT nama_tugas FROM tugas WHERE ID_tugas='".$array_tugas[$i]."'");
				$row=mysqli_fetch_array($result);
				$nama_tugas[$i]=$row['nama_tugas'];
				$i++;
			}
			
			
			$i=0;
			
			while ($i < count($array_tugas))
			{
				if ($array_status_tugas[$i] == "Selesai") echo "<a href=\"detailtugas.php?ID_tugas=".$array_tugas[$i]."\">".$nama_tugas[$i]."</a><br>";
				$i++;
			}		
		
			echo "Task yang sedang dikerjakan:<br>";
		
			$i=0;
			
			while ($i < count($array_tugas))
			{
				if ($array_status_tugas[$i] != "Selesai") echo "<a href=\"detailtugas.php?ID_tugas=".$array_tugas[$i]."\">".$nama_tugas[$i]."</a><br>";
				$i++;
			}		
		
			mysqli_close($con);		
		?>		
			
		<!-- form untuk mengedit atirbut pengguna-->
		<form id="editprofile" name="editprofile" action="editprofile.php" method="POST" enctype="multipart/form-data">
			<br>
			Form edit profile<br>
			Full name: <input type="text" id="editfullname" name="editfullname" onkeyup="return checkNama()&">
			<div id="namawarning"></div><br> 
			Password: <input type="password" id="editpassword" name="editpassword" onkeyup="checkPassword()">
			<!-- field input diatas harus diliat lagi di bagian keyup (yang getelementbyid)-->
			 <div id="passwordwarning"></div><br>
			Confirm password: <input type="password" id="editconfirmpassword" name="editconfirmpassword" onkeyup="checkConfirmPassword()">
			<!-- field input diatas harus diliat lagi di bagian keyup (yang getelementbyid)--> 
			 <div id="confirmwarning"></div><br>
			Email: <input type="text" id="editemail" name="editemail" onkeyup="checkEmail()">
			 <div id="emailwarning"></div><br>
			Birthday: <input type="text" id="birthday" name="editbirthday">
			 <div id="birthdaywarning"></div><br>
			Avatar:<br>
			<label for="file">Filename</label>
			<input type="file" name="file" id="file"><br>
			<input type="submit" value="Edit !">
		</form>
	</body>
</html>
<html>
<head><title>Page mentera</title></head>
<body>
<?php
	$ID_tugas=$_GET["ID_tugas"];
	$con=mysqli_connect("localhost","progin","progin","progin_405_13510099");
	$result=mysqli_query($con,"SELECT * FROM komentar_tugas WHERE ID_tugas='".$ID_tugas."' ORDER BY waktu_komentar ASC");
	$i=0;
	$array_username_komentar=array(); //array berisi username yang mengisi komentar tugas.
	$array_komentar=array(); //array berisi komentar
	$array_waktu_komentar=array(); //array berisi waktu komentar diberikan
	//mengambil data komentar dari database dan memasukkannnya ke dalam array
	while ($row=mysqli_fetch_array($result))
	{
		$array_username_komentar[$i]=$row['username'];
		$array_komentar[$i]=$row['komentar'];
		$array_waktu_komentar[$i]=$row['waktu_komentar'];
		$i++;
	}
	
	$i=0;
	$array_avatar=array();
	while ($i < count($array_username_komentar))
		{
			$result=mysqli_query($con,"SELECT avatar FROM user");
			$row=mysqli_fetch_array($result);
			$array_avatar[$i]=$row["avatar"];
			$i++;
			}
	
	$i=0;
	while ($i < count($array_komentar))
	{
		echo "Avatar komentator: "."<br>".$array_avatar[$i];
		echo "Waktu komentar: ".$array_waktu_komentar[$i]."<br>";
		echo "Isi komentar: ".$array_komentar[$i]."<br>";
		//if ($array_username_komentar == $current_username)
	 	//{echo "<a href=\"hapus_komentar.php\">Hapus komentar ini</a>";};		
		$i++;
	}
	mysqli_close($con);
?>
</body>
</html>
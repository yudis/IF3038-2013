<!--notif reg failed-->
<head>
	<title>Registration Failed</title>
	<link rel="stylesheet" type="text/css" media="all" href="style.css" />
</head>

<body>
<header >	
			
	<div id="tes">
	<h1 id="logo"><img src="images/logo.png"/></a>
	</div>
</header>	
		<div id="logincontent">
			<p> Registrasi Gagal </p>				
			<a href="index.php" target="_parent"> << Back To Home Page </a>
		</div>
		<footer id="colophon">
			<div id="site-generator">
				<p>&copy; <a href="#">KITA</a>-IF3038 Pemrograman Internet 2013 <br />
				</p>
			</div>
		</footer>
		
</body>
<html>
	<head>
	<link rel="stylesheet" href="style.css" type="text/css" media="screen">
		<title>ToDoList - Detail Tugas</title>
	</head>
	<body>
		<?php			
			$ID_tugas=$_GET['ID_tugas'];
			echo 
				"
			<script>
			function edit_task()
			{
				var formtag_open=\"<form name=\\\"edittugas\\\">\";
				var formtag_close=\"</form>\";
			    var tag=\"Tambah tag: <input type=\\\"text\\\" name=\\\"tag\\\"><br>\";
				var hapus_tag=\"hapus tag: <input type=\\\"text\\\" name=\\\"hapus_tag\\\"><br>\";
				var deadline=\"Deadline: <input type=\\\"text\\\" name=\\\"deadline\\\"><br>\"
				var assignee=\"Tambah assignee: <input type=\\\"text\\\" name=\\\"assignee\\\"><br>\";
				var hapus_assignee=\"Hapus assignee: <input type=\\\"text\\\" name=\\\"hapus_assignee\\\"><br>\";
				var submit=\"<div id=\\\"submit\\\" onclick=\\\"edit_task_ajax()\\\">KLIK UNTUK EDIT</div><br>\";
				var stringform=formtag_open+tag+hapus_tag+deadline+assignee+hapus_assignee+submit+formtag_close;
				document.getElementById(\"atribut\").innerHTML=stringform;	
				document.getElementById(\"editbutton\").innerHTML=\"\";
			}
			function page_update()
			{
				var xmlhttp;
				if (window.XMLHttpRequest)
				{
					xmlhttp=new XMLHttpRequest();
				}
				else
				{
					xmlhttp=new ActiveXObject(\"Microsoft.XMLHTTP\");
				}
				xmlhttp.onreadystatechange=function()
					{
						if (xmlhttp.readystate==4)
							{
								document.getElementById(\"pagelist\").innerHTML=xmlhttp.responseText;
							}
					}
				xmlhttp.open(\"GET\",\"pageupdater.php?ID_Tugas=".$ID_tugas."\",true);
				xmlhttp.send();
			}
			function page_view(page_number) //fungsi ajax untuk melihat komentar per halaman
			{
				var xmlhttp;
				if (window.XMLHttpRequest)
				{
					xmlhttp=new XMLHttpRequest();
				}
				
				else
				{
					xmlhttp=new ActiveXObject(\"Microsoft.XMLHTTP\");
				}
				xmlhttp.onreadystatechange=function()
					{
						if (xmlhttp.readystate==4)
							{
								document.getElementById(\"komentar\").innerHTML=xmlhttp.responseText;
								
							}
					}
				xmlhttp.open(\"GET\",\"pageviewer.php?page_ke=\"+page_number.value,true);
				xmlhttp.send();
			}
			function edit_task_ajax()
			{
				var assignee=document.forms[\"edittugas\"][\"assignee\"].value;
				var tag=document.forms[\"edittugas\"][\"tag\"].value;
				var deadline=document.forms[\"edittugas\"][\"deadline\"].value;
				var hapus_assignee=document.forms[\"edittugas\"][\"hapus_assignee\"].value;
				var hapus_tag=document.forms[\"edittugas\"][\"hapus_tag\"].value;
				
				var xmlhttp;
				
				if (window.XMLHttpRequest)
				{
					xmlhttp=new XMLHttpRequest();
				}
				else
				{
					xmlhttp=new ActiveXObject(\"Microsoft.XMLHTTP\");
				}
				xmlhttp.onreadystatechange=function()
					{
						if (xmlhttp.readystate==4&&xmlhttp.status==200)
							{
								document.getElementById(\"atribut\").innerHTML=xmlhttp.responseText;
							}							
						}
				xmlhttp.open(\"GET\",\"edittugas.php?ID_Tugas=".$ID_tugas."\"+\"&tambah_assignee=\"+assignee+\"&deadline=\"+deadline+\"&tambah_tag=\"+tag+\"&hapus_assignee=\"+hapus_assignee+\"&hapus_tag=\"+hapus_tag,true);
				xmlhttp.send();							
			}
			function input_komentar()
			{
				var komen_string=document.forms[\"formkomentar\"][\"fieldkomen\"].value;
				
				var xmlhttp;
				
				if (window.XMLHttpRequest)
				{
					xmlhttp=new XMLHttpRequest();
				}
				else
				{
					xmlhttp=new ActiveXObject(\"Microsoft.XMLHTTP\");
				}
				xmlhttp.onreadystatechange=function()
					{
						if (xmlhttp.readystate==4&&xmlhttp.status==200)
							{
								
							}							
					}
						
				xmlhttp.open(\"GET\",\"inputkomentar.php?komentar=\"+komen_string+\"&ID_Tugas=".$ID_tugas."&username=".$username."\",true);
				xmlhttp.send();					
			}
		
		</script>
			";
			
			$con=mysqli_connect("localhost","progin","progin","progin_405_13510099");
			if (mysqli_connect_errno($con)) {echo "Failed to connect to MySQL: ".mysqli_connect_error();}
			$result=mysqli_query($con,"SELECT * FROM tugas WHERE ID_tugas='".$ID_tugas."';");
			$row=mysqli_fetch_array($result);
			
			//data tentang tugas
			echo "Nama tugas: ".$row['nama_tugas']."<br>";
			echo "Pembuat tugas: ".$row['pembuat_tugas']."<br>";
			echo "Status tugas: ".$row['status']."<br>";
			echo "Attachment: ";
			$Deadline=$row['deadline'];

		
			//informasi assignee tugas
			
			//mengambil data asignee dari database
			
			$hasil=mysqli_query($con,"SELECT * FROM asignee_tugas WHERE ID_tugas='".$ID_tugas."';");
			$array_username_assignee=array(); //array berisi assignee
			$i=0; //buat indeks array
			//memasukkan username assignee ke dalam array
			while ($baris=mysqli_fetch_array($hasil))
			{
				$array_username_assignee[$i]=$baris['username'];
				$i++;
			}
			
			//memasukkan nama lengkap asignee ke dalam array
			$array_namalengkap_assignee=array();
			$i=0;
			$result=mysqli_query($con,"SELECT nama_lengkap FROM user WHERE username='".$array_username_assignee[$i]."';");
			while ($row=mysqli_fetch_array($result))
			{
				$array_namalengkap_assignee[$i]=$row['nama_lengkap'];
				$i++;
				if ($i <= count($array_username_assignee)-1)
					{$result=mysqli_query($con,"SELECT nama_lengkap FROM user WHERE username='".$array_username_assignee[$i]."';");}
			}
	
			$i=0;
			
			echo "<div id=\"atribut\">";
			echo "Deadline tugas: ".$Deadline."<br>";
			//menampilkan nama lengkap asignee ke halaman website beserta hyperlink ke profil masing-masing assignee
			echo "Assignee(s): ";
			echo "<div id=\"assignee\">";//
			while ($i<count($array_namalengkap_assignee))
			{
			echo "<a href=\"profile.php?namalengkap=";
			echo $array_namalengkap_assignee[$i];
			echo "\">";
			echo $array_namalengkap_assignee[$i];
			echo "</a> ,";
			$i++;
			}
			echo "</div>";
			echo "<br>";
			
		
			//mengambil data tags dari tugas ini yang ada di databse
			$result=mysqli_query($con,"SELECT Tag FROM tag_tugas WHERE ID_Tugas='".$ID_tugas."'");		
			$i=0;
			$array_tag_tugas=array(); //array berisi tag tugas
			//memasukkannya ke dalam array
			while ($row=mysqli_fetch_array($result))
			{
				$array_tag_tugas[$i]=$row['Tag'];
				$i++;
			}
			
			$i=0;
			echo "Tags: ";
			
			echo "<div id=\"tag\">";
			while ($i < count($array_tag_tugas))
			{
				echo $array_tag_tugas[$i].",";
				$i++;
	 		}
			echo "</div>";
			echo "</div>"; //penutung tag div atribut
			
			
			echo "<div id=\"editbutton\" onclick=\"edit_task()\">UBAH JADI TEXTFIELD BIAR BISA EDIT</div>";
			//echo "<input type=\"submit\" value=\"Edit atribut\" onclick=\"edit_task()\">";
			
			//menampilkan komentar tugas
			$result=mysqli_query($con,"SELECT * FROM komentar_tugas WHERE ID_tugas='".$ID_tugas."' ORDER BY waktu_komentar");
			$i=0;
			
			$array_username_komentar=array(); //array berisi username yang mengisi komentar tugas.
			$array_komentar=array(); //array berisi komentar
			$array_waktu_komentar=array(); //array berisi waktu komentar diberikan
			//mengambil data komentar dari database dan memasukkannnya ke dalam array
			while ($row=mysqli_fetch_array($result))
			{
				$array_username_komentar[$i]=$row['username'];
				$array_komentar[$i]=$row['komentar'];
				$array_waktu_komentar[$i]=$row['waktu_komentar'];
				$i++;
			}

			$i=0;
			$banyak_komentar=count($array_komentar);
			$banyak_halaman=0;
	if ($banyak_komentar % 10 == 0) {$banyak_halaman=$banyak_komentar/10;}; //jika byk halaman kelipatan 10
	if ($banyak_komentar % 10 != 0) {$banyak_halaman=floor($banyak_komentar/10)+1;}; //jika bayak halaman bukan kelipatan 10
			
			
			
			echo "<br>Komentar<br>";
			
			echo "<div id=\"komentar\">";
			
			
			echo "<iframe src=\"pagekomentar.php?\"></iframe>";

			echo "</div>";
			
			//bagian menampilkan daftar halamn komentar
			
			echo "Input komentar: <br>";
			
			echo "<form name=\"formkomentar\">";
			echo "<textarea name=\"fieldkomentar\" row=10 column=30></textarea>";
			echo "</form>";
			echo "<div id=\"submit_komentar\" onclick=\"input_komentar()\">Submit Komentar</div>";
			
			mysqli_close($con);
		?>
		
		
		
	</body>
</html>
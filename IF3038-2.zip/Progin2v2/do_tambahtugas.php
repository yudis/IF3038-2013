<?php 
	$kategori= $_GET['k'];
	$namaTask= $_POST['namaTask'];
	$deadline= $_POST['deadline'];
	$assignee= $_POST['asignee'];
	$tag= $_POST['tag'];
	$con = mysql_connect("localhost","progin","progin");
	mysql_select_db("progin_405_13510099");
	$fn=$_FILES["fileattach"]["name"];
	$query1 = "INSERT INTO `tugas` 
	(`nama_tugas`, `deadline`, `attachment`, `tag`, `kategori`, `status`, `pembuat_tugas`) 
	VALUES 
	('$namaTask', '$deadline', '$fn', '$tag', '$kategori', 'Unfinish', 'rere');";
	
	$hasil= mysql_query($query1);
	header('Location: dashboard.php'); 
	if($hasil) {
	if ($_FILES["file"]["error"] > 0)
		{
		$_FILES["file"]["error"] . "<br />";
		}
	  else
		{
		echo "Upload: " . $_FILES["file"]["name"] . "<br />";
		echo "Type: " . $_FILES["file"]["type"] . "<br />";
		echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
		echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";

		
		  move_uploaded_file($_FILES["file"]["tmp_name"],
		  "upload/" . $_FILES["file"]["name"]);
		  echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
		  echo "Data telah tersimpan.";
		}
	}
	else echo "Error! Upload gagal";

?>
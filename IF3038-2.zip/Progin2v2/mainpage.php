<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <title>S.Y.N. Share Your Notes</title>
        <link rel="stylesheet" href="loginpage.css" type="text/css" media="screen">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
		
        <iframe src="header.php" height="300" width="1250" name="atas">
        </iframe>
        <iframe src="dashboard.php" height="750" width="1250" name="bawah">
        </iframe>
    </body>
</html>

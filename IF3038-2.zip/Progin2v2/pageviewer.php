
	<?php
		$page_ke=$_GET['pagenumber']; //mengambil parameter bernama pagenumber yaitu page komentar yang ingin dilihat
		$con=mysqli_connect("localhost","progin","progin","progin_405_13510099");
		$result=mysqli_query($con,"SELECT * FROM komentar_tugas WHERE ID_Tugas='".$ID_Tugas."'");

		//menampilkan komentar tugas
			$result=mysqli_query($con,"SELECT * FROM komentar_tugas WHERE ID_tugas='".$ID_tugas."' ORDER BY waktu_komentar asc"); //sorted ascending
			$i=0
			$array_username_komentar=array(); //array berisi username yang mengisi komentar tugas.
			$array_komentar=array(); //array berisi komentar
			$array_waktu_komentar=array(); //array berisi waktu komentar diberikan
			//mengambil data komentar dari database dan memasukkannnya ke dalam array
			while ($row=mysqli_fetch_array($result))
			{
				$array_username_komentar[$i]=$row['username'];
				$array_komentar[$i]=$row['komentar'];
				$array_waktu_komentar=$row['waktu_komentar'];		
				$i++;
			}	
			
			
			echo "<br>Komentar<br>";
			echo "Banyaknya komentar: ".count($array_komentar)."<br>";
			
			//rumus indeks nya
			//hal=1 0..4
			//hal=2 5..9
			//gal=3 10..14, 
			
			$indeksawal=($page_ke-1)*5; //
			$indeksakhir=indeksawal+4;
			$i=indeksawal;
			
			while ($i <= $indeksakhir)
			{
				echo "Avatar: <br>"; //belum diisi, nanti
				echo "Waktu: <br>".$array_waktu_komentar[$i];
				echo "Isi komentar: <br><br>".$array_komentar[$i];
				$i++;
			}
			
		mysqli_close($con);
	?>

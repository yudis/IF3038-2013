<html>
	<head>
		<title>ToDoList - Halaman Pembuatan Tugas</title>
	</head>
	<body>
		<form action="upload.php" method="post" enctype="multipart/form-data">
			<label for="file">Filename: </label>
			<input type="file" name="file" id="file"><br>
			<input type="submit" name="submit" value="dor">
		</form>
	</body>
</html>
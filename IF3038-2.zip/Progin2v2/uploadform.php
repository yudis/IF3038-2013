<html>
	<head><title></title></head>
	<body>
		<form action="file_uploader.php" method="POST" enctype="multipart/form-data">	
		
		<input type="file" name="file" id="file"><br>
		<input type="submit" name="submit" value="haha">
		</form>
	</body>
</html>
<?php
session_start();
 $userid = $_SESSION['userid'];
 $pwd = $_SESSION['pwd'];
 
 if($userid && $pwd){
	header( 'Location: mainpage.php' ) ; }
 else
 {
   function login()
   {
	   $connect = mysql_connect("localhost", "root", "");
	   if(!$connect)
	   {
		   die(mysql_error());
	   }
	   
	   $select_db = mysql_select_db("progin_405_13510099");
	   if(!$select_db)
	   {
		   die(mysql_error());
	   }

	   $result = mysql_query("SELECT * FROM user WHERE username ='$userid'");
	   $row = mysql_fetch_array($result);

	   $user = $row['userid'];
	   if($userid != $user)
	   {
		  die("<br /> Can't find username from db!<br /> ");
	   }

	   $real_password = $row['pwd'];
	   if($password != $real_password)
	   {
			 die("<br />Your password is wrong!<br /> ");
	   }

	   $_SESSION['userid']=$userid;
	   $_SESSION['pwd']=$pwd;

	   header( 'Location: mainpage.php' ) ;
   }
   if (isset($_REQUEST['login']))
   { 
	   login(); 
   }
   else
   {
	   header( 'Location: mainpage.php' ) ;
   }
 }
?>
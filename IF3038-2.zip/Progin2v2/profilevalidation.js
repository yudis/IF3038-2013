function password_check(pass)
{
	if (pass.value.length < 8) {document.getElementById("passwordwarning").innerHTML="Password minimal harus 8 karakter";return false;}
	else if (pass.value == "" || pass == null) {document.getElementById("passwordwarning").innerHTML="Password tidak boleh kosong";return false;} 
	else {document.getElementById("passwordwarning").innerHTML="Sudah benar";return true;};
}

function confirmpassword_check(pass,confpass)
{
	if (pass.value != confpass.value) {document.getElementById("confirmwarning").innerHTML="Confirm password dan password harus sama!";return false;}
	else if (confpass.value == "" || confpass == null) {document.getElementById("confirmwarning").innerHTML="Confirm password tidak boleh kosong!";return
	false;}
	else {document.getElementById("confirmwarning").innerHTML="Sudah benar";return true};
}

function namalengkap_check(nama) {
    var spacepos=nama.indexOf(" ");
    if(nama=="" || nama==null)
        {document.getElementById("namawarning").innerHTML="*Nama tidak boleh kosong";return false;}
    else
        if(spacepos<0)
            {document.getElementById("namawarning").innerHTML="*Nama minimal 2 kata";return false;}
        else
            {document.getElementById("namawarning").innerHTML="";return true;}
}

function email_check(email) 
{
    var atpos=email.indexOf("@");
    var dotpos=email.lastIndexOf(".");
    if(email=="" || email==null)
        {document.getElementById("emailwarning").innerHTML="*E-mail tidak boleh kosong";return false;}
    else
        if(atpos<1 || dotpos<atpos+1 || (dotpos+2)>=email.length)
            {document.getElementById("emailwarning").innerHTML=("*e-mail tidak valid");return false;}
        else
            {document.getElementById("emailwarning").innerHTML="";return true;}
}

function extension_check(filename) 
{
      var re = /\..+$/;
      var ext = filename.match(re);
      if(!(ext==".jpg" || ext==".jpeg"))
           {document.getElementById("avatarwarning").innerHTML="ekstensi file tidak diterima";return false;}
       else
           {document.getElementById("avatarwarning").innerHTML="";return true;}
}

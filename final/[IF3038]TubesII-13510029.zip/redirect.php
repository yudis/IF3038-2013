<?php
	$destination=$_GET["page"];
	header( "Location: dashboard.php?uname=".$username."&cat=all" ) ;
?>
IF3038-2013
===========

Repositori ini adalah repositori dasar yang akan dijadikan basis oleh setiap kelompok peserta kuliah IF3038.
Pengumpulan Tugas:
- Sebutkan URL repositori yang akan dinilai
  - Repositori ini harus merupakan fork dari repo ini (baik secara langsung atau tidak langsung)
- Sebutkan anggota dari kelompok (NIM NAMA MAIL GITHUB_ID)
- Kontributor dari repositori tersebut HANYA anggota kelompok yang bersangkutan

Rule dan Konvensi:
- Setiap peserta harus menggunakan akun pribadi, dan bukan shared-account, pada setiap kegiatan/hubungan dengan github
- Proyek yang dikumpulkan harus memuat file berikut:
  - INSTALL.md - berisi how-to untuk proses peng-install-an dari aplikasi
  - MEMEBER.md - berisi NIM NAMA MAIL GITHUB_ID dari anggota grup ini
  - src/ - berisi semua kode sumber dari aplikasi yang akan anda kumplukan
  - docs/ - berisi dokumentasi dari aplikasi, jika diperlukan
